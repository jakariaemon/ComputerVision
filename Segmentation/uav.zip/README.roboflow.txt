
UAV Detection - v1 2022-04-06 9:03pm
==============================

This dataset was exported via roboflow.ai on April 6, 2022 at 3:04 PM GMT

It includes 19 images.
Quadcoptor are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 800x600 (Stretch)

No image augmentation techniques were applied.


